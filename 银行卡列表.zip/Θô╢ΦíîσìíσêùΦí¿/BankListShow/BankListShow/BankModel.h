//
//  BankModel.h
//  BankListShow
//
//  Created by XinHuiOS on 2019/4/29.
//  Copyright © 2019 XinHuiOS. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BankModel : NSObject
/**
 银行编号
 **/
@property (nonatomic, copy) NSString *bankserial;
/**
 银行名称
 **/
@property (nonatomic, copy) NSString *bank_name;
/**
 限额信息
 **/
@property (nonatomic, copy) NSString *quota;
/**
 银行logo
 **/
@property (nonatomic, copy)NSString *bankimage;
/**
 是否是常用的16家银行
 **/
@property (nonatomic, assign)BOOL isBaseBank;

@end

NS_ASSUME_NONNULL_END
