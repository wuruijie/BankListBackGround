//
//  AppDelegate.h
//  BankListShow
//
//  Created by XinHuiOS on 2019/4/29.
//  Copyright © 2019 XinHuiOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

