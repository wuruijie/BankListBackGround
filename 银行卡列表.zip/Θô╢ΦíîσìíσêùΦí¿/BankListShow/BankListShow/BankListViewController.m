//
//  BankListViewController.m
//  BankListShow
//
//  Created by XinHuiOS on 2019/4/29.
//  Copyright © 2019 XinHuiOS. All rights reserved.
//

#import "BankListViewController.h"
#import "BankModel.h"
#import "MineBankCell.h"
@interface BankListViewController ()
@property (nonatomic, strong)NSMutableArray * dataArray;
@end

@implementation BankListViewController

-(NSMutableArray *)dataArray {
    if (!_dataArray) {
        _dataArray =[[NSMutableArray alloc] init];
    }
    return _dataArray;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title =@"银行卡背景色";
    //JSON文件的路径
    NSString *path = [[NSBundle mainBundle] pathForResource:@"bankList.json" ofType:nil];
    //加载JSON文件
    NSData *data = [NSData dataWithContentsOfFile:path];
    //将JSON数据转为NSArray或NSDictionary
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    NSArray * resultArr =dict[@"result"];
    
    for (NSDictionary *dict in resultArr) {
        BankModel *model = [[BankModel alloc]init];
        model.bank_name =  dict[@"bank_name"];
        model.bankserial = dict[@"bankserial"];
        model.bankimage  = dict[@"bankimage"];
        //model.isBaseBank = NO;
        [self.dataArray addObject:model];
    }
    self.tableView.rowHeight = 192;
    [self.tableView registerNib:[UINib nibWithNibName:@"MineBankCell" bundle:nil] forCellReuseIdentifier:@"MineBankCell"];
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.tableView reloadData];
}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MineBankCell * cell =[tableView dequeueReusableCellWithIdentifier:@"MineBankCell" forIndexPath:indexPath];
    
    cell.bank = self.dataArray[indexPath.row];
   
    return cell;
}
@end
