//
//  ViewController.m
//  BankListShow
//
//  Created by XinHuiOS on 2019/4/29.
//  Copyright © 2019 XinHuiOS. All rights reserved.
//

#import "ViewController.h"
#import "BankListViewController.h"
@interface ViewController ()

@end

@implementation ViewController

-(instancetype)init {
    if (self =[super init]) {
        self.title = @"银行卡列表";
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton * selectBtn =[UIButton buttonWithType:UIButtonTypeCustom];
    selectBtn.frame =  CGRectMake(self.view.frame.size.width/2-100,300,200,50);
    selectBtn.backgroundColor =[UIColor cyanColor];
    [selectBtn setTitle:@"查看列表" forState:UIControlStateNormal];
    [selectBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    selectBtn.layer.cornerRadius = 10;
    selectBtn.layer.masksToBounds = YES;
    [selectBtn addTarget:self action:@selector(chooseBank:)
        forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:selectBtn];

}
-(void)chooseBank:(UIButton *)btn {
    BankListViewController *lis =[[BankListViewController alloc] init];
    [self.navigationController pushViewController:lis animated:YES];
}
@end
