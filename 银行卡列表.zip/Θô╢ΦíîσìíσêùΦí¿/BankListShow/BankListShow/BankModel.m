//
//  BankModel.m
//  BankListShow
//
//  Created by XinHuiOS on 2019/4/29.
//  Copyright © 2019 XinHuiOS. All rights reserved.
//

#import "BankModel.h"

@implementation BankModel

@end
