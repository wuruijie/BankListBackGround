//
//  ViewController.h
//  BankListShow
//
//  Created by XinHuiOS on 2019/4/29.
//  Copyright © 2019 XinHuiOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

