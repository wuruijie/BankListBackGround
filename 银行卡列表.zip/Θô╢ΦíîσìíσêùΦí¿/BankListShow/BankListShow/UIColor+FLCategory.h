//
//  UIColor+FLCategory.h
//  FLBaseModule
//
//  Created by forterli on 2018/1/4.
//  Copyright © 2018年 forterli. All rights reserved.
//

#import <UIKit/UIKit.h>

#pragma mark - Color
/** RGBColor */
#define kRGBColor(r, g, b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1.0]
/** RGBAColor */
#define kRGBAColor(r, g, b, a) [UIColor colorWithRed:(r)/255.0 green:(r)/255.0 blue:(r)/255.0 alpha:a]
/** RandomColor */
#define kRandomColor kRGBColor(arc4random_uniform(256),arc4random_uniform(256),arc4random_uniform(256))
/** clearColor */
#define kClearColor [UIColor clearColor]
/** 16进制颜色 */
#define k16Color(rgbValue) \
[UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16)) / 255.0 \
green:((float)((rgbValue & 0xFF00) >> 8)) / 255.0 \
blue:((float)(rgbValue & 0xFF)) / 255.0 alpha:1.0]

@interface FLColorModel : NSObject
@property (nonatomic,assign) int R;
@property (nonatomic,assign) int G;
@property (nonatomic,assign) int B;
@property (nonatomic,assign) CGFloat alpha;

@end

//@class colorModel;

@interface UIColor (FLCategory)

+ (UIColor *)colorRGBIntR:(NSUInteger)r g:(NSUInteger)g b:(NSUInteger)b a:(CGFloat)a;

+ (UIColor *)colorRGBIntR:(NSUInteger)r g:(NSUInteger)g b:(NSUInteger)b;

+(UIColor *)colorWithHexString:(NSString *)stringToConvert;

+(UIColor *)colorWithRGBHex:(UInt32)hex;

+ (UIColor *) colorWithHexString: (NSString *)color withAlpha:(CGFloat)alpha;

+ (FLColorModel *) RGBWithHexString: (NSString *)color withAlpha:(CGFloat)alpha;

+ (UIColor *) colorFromHex:(NSString *)hexColor;

- (BOOL)isEqualToColor:(UIColor *)otherColor;
@end
