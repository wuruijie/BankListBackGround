//
//  MineBankCell.m
//  XinHuWealth
//
//  Created by Xcode_Git on 2019/3/8.
//  Copyright © 2019 zyf. All rights reserved.
//

#import "MineBankCell.h"
#import "BankModel.h"
#import "UIView+AZGradient.h"
#import "UIColor+FLCategory.h"
#import <SDWebImage.h>
@interface MineBankCell ()
@property (weak, nonatomic) IBOutlet UIImageView *headImgView;
@property (weak, nonatomic) IBOutlet UILabel *bankNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *bankNumLabel;
@property (weak, nonatomic) IBOutlet UIImageView *bankBGView;
@property (weak, nonatomic) IBOutlet UIButton *addBankBtn;
@property (weak, nonatomic) IBOutlet UILabel *detailContentLabel;

@property (weak, nonatomic) IBOutlet UIImageView *PayIMageVIew;
//头像的宽度约束
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *iconWConst;

@end

@implementation MineBankCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    _bankBGView.layer.shadowColor = [UIColor blackColor].CGColor;
    _bankBGView.layer.shadowOpacity = 1;
    _bankBGView.layer.shadowOffset = CGSizeMake(0, 8);
    _bankBGView.layer.shadowOpacity = 0.5;
//    _bankBGView.layer.masksToBounds = YES;
    _bankBGView.layer.cornerRadius = 8;
    _headImgView.layer.masksToBounds = YES;
    _headImgView.layer.cornerRadius = 20;
    _addBankBtn.layer.masksToBounds = YES;
    _addBankBtn.layer.cornerRadius = 16;
}

-(void)setBank:(BankModel *)bank {
    _headImgView.hidden = NO;
    _bankNameLabel.hidden = NO;
    _bankNumLabel.hidden = NO;
    _addBankBtn.hidden =YES;
    self.detailContentLabel.hidden = NO;
    self.PayIMageVIew.hidden = NO;
    _bankNameLabel.text = bank.bank_name;
    _bankNumLabel.text = bank.bankserial;
    NSString * hexColorFront;
    NSString * hexColorDown;
    //浦发
    if ([bank.bankserial isEqualToString:@"010"]) {
        hexColorFront = @"#061f5c";
        hexColorDown  = @"#0c3393";
        //工商
    }else if ([bank.bankserial isEqualToString:@"002"]) {
        hexColorFront  = @"#c3282b";
        hexColorDown   = @"#e43639";
    }
    //农业
    else if ([bank.bankserial isEqualToString:@"003"]) {
        hexColorFront = @"#097f6f";
        hexColorDown  = @"#0ca88b";
    }
    //中国
    else if ([bank.bankserial isEqualToString:@"004"]) {
        hexColorFront = @"#b30f31";
        hexColorDown  = @"#e51f4a";
    }
    //建设
    else if ([bank.bankserial isEqualToString:@"005"]) {
        hexColorFront = @"#0c5cca";
        hexColorDown  = @"#426cf7";
    }
    //交通
    else if ([bank.bankserial isEqualToString:@"006"]) {
        hexColorFront = @"#1c326b";
        hexColorDown  = @"#405fb0";
    }
    //招商
    else if ([bank.bankserial isEqualToString:@"007"]) {
        hexColorFront = @"#a61f23";
        hexColorDown  = @"#db3d42";
    }
    //光大
    else if ([bank.bankserial isEqualToString:@"009"]) {
        hexColorFront = @"#8425a1";
        hexColorDown  = @"#cf54f8";
    }
    //兴业
    else if ([bank.bankserial isEqualToString:@"011"]) {
        hexColorFront = @"#003a79";
        hexColorDown  = @"#0956a9";
    }
    //华夏
    else if ([bank.bankserial isEqualToString:@"012"]) {
        hexColorFront = @"#c4282b";
        hexColorDown  = @"#eb3235";
    }
    //民生
    else if ([bank.bankserial isEqualToString:@"014"]) {
        hexColorFront = @"#27a1a6";
        hexColorDown  = @"#004d97";
    }
    //中信
    else if ([bank.bankserial isEqualToString:@"015"]) {
        hexColorFront = @"#d00707";
        hexColorDown  = @"#f61a1a";
    }
    //广发
    else if ([bank.bankserial isEqualToString:@"016"]) {
        hexColorFront = @"#bf0017";
        hexColorDown  = @"#e60021";
    }
    //上海
    else if ([bank.bankserial isEqualToString:@"017"]) {
        hexColorFront = @"#12489e";
        hexColorDown  = @"#1b63d6";
    }
    //平安
    else if ([bank.bankserial isEqualToString:@"920"]) {
        hexColorFront = @"#ff3604";
        hexColorDown  = @"#ff5126";
    }
    //邮政
    else if ([bank.bankserial isEqualToString:@"934"]) {
        hexColorFront = @"#286836";
        hexColorDown  = @"#327341";
    }else {
        hexColorFront =@"#EF9A5B";
        hexColorDown =@"#E95D2C";
    }
    _bankBGView.image = nil;
    [self setBackColor:hexColorFront GrandiColor:hexColorDown];
    if (bank.bankserial.length) {
        [_headImgView sd_setImageWithURL:[NSURL URLWithString:bank.bankimage]];
        self.iconWConst.constant  = 40;
    }else {
        self.PayIMageVIew.hidden = YES;
        self.iconWConst.constant = 0;
    }
}
#pragma mark 设置背景渐变色
-(void)setBackColor:(NSString *)hexColorfront GrandiColor:(NSString *)hexColorDown {
   
    [_bankBGView az_setGradientBackgroundWithColors:@[[UIColor colorFromHex:hexColorfront],[UIColor colorFromHex:hexColorDown]] locations:nil startPoint:CGPointMake(0, 0) endPoint:CGPointMake(1, 0)];
}
@end
