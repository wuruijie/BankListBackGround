//
//  MineBankCell.h
//  XinHuWealth
//
//  Created by Xcode_Git on 2019/3/8.
//  Copyright © 2019 zyf. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BankModel;

@interface MineBankCell : UITableViewCell

@property (nonatomic, strong)BankModel  * bank;


@end

